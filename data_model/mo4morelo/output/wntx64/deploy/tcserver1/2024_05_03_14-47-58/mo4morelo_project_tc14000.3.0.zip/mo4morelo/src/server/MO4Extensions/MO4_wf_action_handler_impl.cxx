/*
 * MO4_wf_action_handler_impl.cxx
 *
 *  Created on: May 2, 2024
 *      Author: install
 */

#include "MO4_wf_action_handler_impl.hxx"
#include "MO4_utils.hxx"
#include <tccore/design.h>

/**
* This handler is designed to add schedule member to Schedule object.
*
*/
int MO4_ah_create_part_for_design
(
	EPM_action_message_t msg
)
{
	//const char *szFunctionName = "MO4_ah_create_part_for_design";

	int				iRetCode = ITK_ok;
    int             i = 0 ;
    int             iAttachmentCount = 0;

    int * 	error_codes = NULL;
    char* sItemId = NULL;
    char ** 	error_messages  = NULL;

	//int             iAnalystCount = 0;
//	int             iRelatedObjCount = 0;
//	int				invalid_input_index = 0;
//	int				num_added_members = 0;
//	int				iAvailableSchMembersCnt = 0;
//
//	logical         old_bypass = false;
//	logical         lMemberFound = false;

    logical * 	part_required_values = NULL;


	char            *pcObjectType = NULL ;
//	char            *pcBreakdownObjType = NULL;

    //char            *pcTargetType = NULL ;
	//char			*pcAnalystUserId = NULL;
	////char            *pcAnalystUID = NULL;
	////char			*pcCost = "0.00";
	////char			*pcCurrency = "USD";
	//char            *pcSchMemUserId = NULL;

    tag_t           tRootTask = NULLTAG ;
	//tag_t           tRelationType = NULLTAG;
	//tag_t			tScheduleObj = NULLTAG;
	//tag_t			tParticipantType = NULLTAG;
	//////tag_t			tAssigneeUser = NULLTAG;
	//tag_t           tScheduleMember = NULLTAG;

//	tag_t*          ptAnalysts = NULL;
	tag_t*          ptAttachments = NULL;
//    tag_t*          ptRelatedObjs  = NULL;
//	tag_t*			ptScheduleMembers = NULL;
//	tag_t*			ptAvailableSchMembers = NULL;

	//AddMembers_t	add_member_inputs;

	//PRINTLOG((">>>%s::", szFunctionName));

	//iRetCode = SMA8_wf_arg_get_wf_argument_value(msg.arguments, msg.task, SMA8_WF_ARG_TARGET_TYPE, false, &pcTargetType));
	//TC_write_syslog("\npcTargetType = %s", pcTargetType);

    // Find all attachments
    iRetCode = EPM_ask_root_task ( msg.task , &tRootTask );

    iRetCode = EPM_ask_attachments ( tRootTask , EPM_target_attachment , &iAttachmentCount , &ptAttachments );

    TC_write_syslog("\niAttachmentCount = %d", iAttachmentCount);

	// Get the relation type tag of "CMHasWorkBreakdown"
    //SMA_ITKCALL(iRetCode, GRM_find_relation_type("CMHasWorkBreakdown", &tRelationType));

	//SMA_ITKCALL(iRetCode, TCTYPE_find_type("Analyst", "Analyst", &tParticipantType));

    if(iAttachmentCount > 0)
    {
    	iRetCode = DESIGN_ask_part_required(ptAttachments, iAttachmentCount, &part_required_values, &error_codes, &error_messages);
    }

    // Loop through all attachments
    for ( i = 0 ; ( i < iAttachmentCount ) && ( iRetCode == ITK_ok ) ; i++ )
    {
        iRetCode = WSOM_ask_object_type2 ( ptAttachments[i] , &pcObjectType );
        iRetCode = AOM_ask_value_string(ptAttachments[i], "item_id", &sItemId);

    	if(part_required_values[i] == true)
    	{
    		TC_write_syslog("\npcObjectType = %s, sItemId = %s, part_required_value = %d", pcObjectType, sItemId, part_required_values[i]);
    	}
    }

    //SMA_MEM_TCFREE(ptAttachments);

	//SMA_MEM_TCFREE(pcObjectType);
	////////SMA_MEM_TCFREE(pcTargetType);

	//PRINTLOG(("<<<%s::", szFunctionName));

    return iRetCode;
}

