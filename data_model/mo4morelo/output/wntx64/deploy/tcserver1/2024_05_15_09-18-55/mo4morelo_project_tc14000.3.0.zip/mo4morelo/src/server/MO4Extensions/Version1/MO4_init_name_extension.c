//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension MO4_init_name_extension
 *
 */
#include <MO4Extensions/MO4_init_name_extension.h>

int MO4_init_name_extension( METHOD_message_t *msg, va_list args )
{
 msg; args;
 return 0;

}